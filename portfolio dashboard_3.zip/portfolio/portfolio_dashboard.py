#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
포트폴리오 모니터링 대시보드 (버킷 분리판)
- 일반 위탁 / DC 퇴직연금 / IRP 세 버킷으로 나눠서 봄
- 한국주식·ETF + 미국주식 + 환율 반영
- 전체 합계 + 버킷별 표 + 자산군(섹터) 분산 + 쏠림 알림
- HTML 대시보드 출력, (옵션) Notion 동기화

사용법:
    python portfolio_dashboard.py
    python portfolio_dashboard.py --setup-notion
"""
import sys, csv, datetime as dt
from pathlib import Path
from collections import defaultdict, OrderedDict

try:
    import yaml
except ImportError:
    print("pyyaml 필요: pip install pyyaml"); sys.exit(1)

BASE = Path(__file__).resolve().parent
CONFIG_PATH = BASE / "config.yaml"
HOLDINGS_PATH = BASE / "holdings.csv"
OUTPUT_HTML = BASE / "dashboard.html"


# ── 입력 ────────────────────────────────────────────────
def load_config():
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH, encoding="utf-8") as f:
            return yaml.safe_load(f)
    return {"concentration_threshold": 0.25, "sector_threshold": 0.40,
            "notion": {"enabled": False}}

def load_holdings():
    rows = []
    with open(HOLDINGS_PATH, encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            if not r.get("ticker"):
                continue
            rows.append({
                "bucket": (r.get("bucket") or "기타").strip(),
                "account": (r.get("account") or "").strip(),
                "ticker": r["ticker"].strip(),
                "market": r["market"].strip().upper(),
                "shares": float(r["shares"]),
                "avg_cost": float(r["avg_cost"]),
                "name": (r.get("name") or "").strip(),
                "sector": (r.get("sector") or "").strip(),
            })
    return rows


# ── 시세/환율/섹터 (사용자 PC에서만 동작) ────────────────
def get_usdkrw():
    import FinanceDataReader as fdr
    return float(fdr.DataReader("USD/KRW")["Close"].dropna().iloc[-1])

_KR_LIST = None
def _kr_listing():
    global _KR_LIST
    if _KR_LIST is None:
        import FinanceDataReader as fdr
        df = fdr.StockListing("KRX")
        if "Code" not in df.columns and "Symbol" in df.columns:
            df = df.rename(columns={"Symbol": "Code"})
        _KR_LIST = df
    return _KR_LIST

def get_kr_quote(h):
    import FinanceDataReader as fdr
    price = float(fdr.DataReader(h["ticker"])["Close"].dropna().iloc[-1])
    name = h["name"] or h["ticker"]
    sector = h["sector"] or "기타"
    if not h["name"]:
        try:
            hit = _kr_listing(); hit = hit[hit["Code"] == h["ticker"]]
            if len(hit): name = str(hit.iloc[0].get("Name", name))
        except Exception:
            pass
    return price, name, sector

def get_us_quote(h):
    import yfinance as yf
    t = yf.Ticker(h["ticker"])
    price = None
    fi = getattr(t, "fast_info", None)
    if fi is not None:
        price = float(fi.get("last_price") or 0) or None
    if not price:
        price = float(t.history(period="5d")["Close"].dropna().iloc[-1])
    name, sector = h["name"] or h["ticker"], h["sector"] or "Unknown"
    if not h["name"] or not h["sector"]:
        try:
            info = t.info
            if not h["name"]:   name = info.get("shortName") or name
            if not h["sector"]: sector = info.get("sector") or sector
        except Exception:
            pass
    return price, name, sector

def fetch_quote(h):
    if h["market"] == "KR":
        p, n, s = get_kr_quote(h); cur = "KRW"
    else:
        p, n, s = get_us_quote(h); cur = "USD"
    return {"price": p, "name": n, "sector": s, "currency": cur}


# ── 계산 ────────────────────────────────────────────────
def compute(holdings, quotes, usdkrw, config):
    # (bucket,ticker)로 합산
    agg = OrderedDict()
    for h in holdings:
        q = quotes[h["ticker"]]
        fx = usdkrw if q["currency"] == "USD" else 1.0
        key = (h["bucket"], h["ticker"])
        if key not in agg:
            agg[key] = {"bucket": h["bucket"], "ticker": h["ticker"],
                        "name": q["name"], "market": h["market"],
                        "sector": h["sector"] or q["sector"],
                        "currency": q["currency"], "price": q["price"],
                        "shares": 0.0, "cost_native": 0.0}
        a = agg[key]
        a["shares"] += h["shares"]
        a["cost_native"] += h["avg_cost"] * h["shares"]

    rows = []
    for a in agg.values():
        fx = usdkrw if a["currency"] == "USD" else 1.0
        avg = a["cost_native"] / a["shares"] if a["shares"] else 0
        value_krw = a["price"] * a["shares"] * fx
        cost_krw = avg * a["shares"] * fx
        rows.append({**a, "avg_cost": avg, "value_krw": value_krw,
                     "cost_krw": cost_krw, "pnl_krw": value_krw - cost_krw,
                     "pnl_pct": (a["price"]/avg - 1) if avg else 0})

    total_value = sum(r["value_krw"] for r in rows)
    total_cost = sum(r["cost_krw"] for r in rows)
    for r in rows:
        r["weight"] = r["value_krw"]/total_value if total_value else 0

    # 버킷별 묶기
    buckets = OrderedDict()
    for r in sorted(rows, key=lambda x: x["value_krw"], reverse=True):
        buckets.setdefault(r["bucket"], []).append(r)
    bucket_summ = OrderedDict()
    for b, brs in buckets.items():
        bv = sum(r["value_krw"] for r in brs)
        bc = sum(r["cost_krw"] for r in brs)
        for r in brs:
            r["bucket_weight"] = r["value_krw"]/bv if bv else 0
        bucket_summ[b] = {"value": bv, "cost": bc, "pnl": bv-bc,
                          "pnl_pct": (bv/bc-1) if bc else 0,
                          "weight": bv/total_value if total_value else 0}

    # 자산군(섹터) 분산 — 전체 기준
    sectors = defaultdict(float)
    for r in rows:
        sectors[r["sector"]] += r["weight"]
    sectors = OrderedDict(sorted(sectors.items(), key=lambda x: x[1], reverse=True))

    # 쏠림 알림 — 전체 기준
    ct = config.get("concentration_threshold", 0.25)
    st = config.get("sector_threshold", 0.40)
    alerts = []
    for r in sorted(rows, key=lambda x: x["weight"], reverse=True):
        if r["weight"] > ct:
            alerts.append(f"종목 쏠림: {r['name']} {r['weight']*100:.1f}% (기준 {ct*100:.0f}%)")
    for s, w in sectors.items():
        if w > st:
            alerts.append(f"자산군 쏠림: {s} {w*100:.1f}% (기준 {st*100:.0f}%)")

    return {"buckets": buckets, "bucket_summ": bucket_summ, "sectors": sectors,
            "alerts": alerts, "total_value": total_value, "total_cost": total_cost,
            "total_pnl": total_value-total_cost,
            "total_pnl_pct": (total_value/total_cost-1) if total_cost else 0,
            "usdkrw": usdkrw, "asof": dt.datetime.now().strftime("%Y-%m-%d %H:%M")}


# ── HTML ────────────────────────────────────────────────
def won(x): return f"{x:,.0f}원"
def pct(x): return f"{x*100:+.2f}%"

def render_html(d):
    pc = "pos" if d["total_pnl"] >= 0 else "neg"
    bucket_html = ""
    for b, brs in d["buckets"].items():
        s = d["bucket_summ"][b]
        bpc = "pos" if s["pnl"] >= 0 else "neg"
        tr = ""
        for r in brs:
            cls = "pos" if r["pnl_krw"] >= 0 else "neg"
            nat = f"${r['price']:,.2f}" if r["currency"]=="USD" else f"{r['price']:,.0f}"
            tr += f"""<tr><td><b>{r['name']}</b><span class="tk">{r['ticker']} · {r['sector']}</span></td>
              <td class="num">{r['shares']:g}</td><td class="num">{nat}</td>
              <td class="num">{won(r['value_krw'])}</td>
              <td class="num {cls}">{pct(r['pnl_pct'])}</td>
              <td class="num">{r['bucket_weight']*100:.1f}%</td></tr>"""
        bucket_html += f"""<div class="panel"><div class="bhead">
            <h3>{b}</h3><div class="bsum">{won(s['value'])}
            <span class="{bpc}">{won(s['pnl'])} ({pct(s['pnl_pct'])})</span>
            <span class="bw">전체 {s['weight']*100:.1f}%</span></div></div>
            <table><thead><tr><th>종목</th><th class="num">수량</th><th class="num">현재가</th>
            <th class="num">평가금액</th><th class="num">손익률</th><th class="num">버킷내</th></tr></thead>
            <tbody>{tr}</tbody></table></div>"""

    sec = ""
    for s, w in d["sectors"].items():
        sec += f"""<div class="srow"><span class="slabel">{s}</span>
          <div class="sbar"><span style="width:{w*100:.1f}%"></span></div>
          <span class="sval">{w*100:.1f}%</span></div>"""

    if d["alerts"]:
        al = '<div class="alerts"><h3>⚠ 쏠림 알림</h3><ul>' + \
             "".join(f"<li>{a}</li>" for a in d["alerts"]) + "</ul></div>"
    else:
        al = '<div class="alerts ok"><h3>✓ 쏠림 없음</h3></div>'

    return f"""<!DOCTYPE html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>포트폴리오 대시보드</title>
<style>
:root{{--bg:#0f1115;--card:#1a1d24;--line:#2a2e37;--txt:#e6e8ec;--mut:#8b909a;--pos:#22c55e;--neg:#ef4444;--ac:#6366f1}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--txt);
font-family:-apple-system,'Segoe UI','Apple SD Gothic Neo',sans-serif;padding:28px}}
h1{{font-size:20px;margin:0 0 2px}}.asof{{color:var(--mut);font-size:13px;margin-bottom:20px}}
.cards{{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:14px;margin-bottom:22px}}
.card{{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:16px}}
.card .lbl{{color:var(--mut);font-size:13px;margin-bottom:6px}}.card .big{{font-size:23px;font-weight:700}}
.pos{{color:var(--pos)}}.neg{{color:var(--neg)}}
.grid{{display:grid;grid-template-columns:1.7fr 1fr;gap:18px;align-items:start}}
@media(max-width:860px){{.grid{{grid-template-columns:1fr}}}}
.panel{{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px;margin-bottom:16px}}
.bhead{{display:flex;justify-content:space-between;align-items:baseline;flex-wrap:wrap;gap:8px;margin-bottom:12px}}
.panel h3{{margin:0;font-size:15px}}.bsum{{font-size:13px;color:var(--mut)}}
.bsum span{{margin-left:10px}}.bw{{color:var(--mut)}}
table{{width:100%;border-collapse:collapse;font-size:13px}}
th{{text-align:left;color:var(--mut);font-weight:500;padding:7px 5px;border-bottom:1px solid var(--line)}}
td{{padding:9px 5px;border-bottom:1px solid var(--line)}}.num{{text-align:right}}
.tk{{display:block;color:var(--mut);font-size:11px;margin-top:2px}}
.srow{{display:flex;align-items:center;gap:10px;margin-bottom:11px;font-size:13px}}
.slabel{{width:130px}}.sbar{{flex:1;height:8px;background:var(--line);border-radius:5px;overflow:hidden}}
.sbar span{{display:block;height:100%;background:linear-gradient(90deg,#6366f1,#8b5cf6)}}
.sval{{width:46px;text-align:right;color:var(--mut)}}
.alerts{{background:var(--card);border:1px solid var(--line);border-left:3px solid var(--neg);border-radius:12px;padding:16px;margin-top:16px}}
.alerts.ok{{border-left-color:var(--pos)}}.alerts h3{{margin:0 0 8px;font-size:14px}}
.alerts ul{{margin:0;padding-left:18px}}.alerts li{{margin:4px 0;font-size:13px}}
.fx{{color:var(--mut);font-size:12px;margin-top:18px}}
</style></head><body>
<h1>📊 포트폴리오 대시보드</h1>
<div class="asof">기준 {d['asof']} · USD/KRW {d['usdkrw']:,.1f}</div>
<div class="cards">
  <div class="card"><div class="lbl">총 평가금액</div><div class="big">{won(d['total_value'])}</div></div>
  <div class="card"><div class="lbl">총 평가손익</div><div class="big {pc}">{won(d['total_pnl'])}</div></div>
  <div class="card"><div class="lbl">총 수익률</div><div class="big {pc}">{pct(d['total_pnl_pct'])}</div></div>
</div>
<div class="grid">
  <div>{bucket_html}</div>
  <div><div class="panel"><h3>자산군 분산 (전체)</h3>{sec}</div>{al}</div>
</div>
<div class="fx">시세·환율은 마지막 종가 기준이며 실시간 호가와 다를 수 있습니다. 연금(DC·IRP)은 인출 제한이 있어 일반 계좌와 성격이 다릅니다.</div>
</body></html>"""


# ── Notion (옵션) ───────────────────────────────────────
def notion_schema():
    return {"종목":{"title":{}},"버킷":{"select":{}},"티커":{"rich_text":{}},
            "수량":{"number":{"format":"number"}},"평가금액(원)":{"number":{"format":"won"}},
            "손익률":{"number":{"format":"percent"}},"비중":{"number":{"format":"percent"}},
            "업데이트":{"date":{}}}

def setup_notion(config):
    from notion_client import Client
    n = config["notion"]; c = Client(auth=n["token"])
    db = c.databases.create(parent={"type":"page_id","page_id":n["parent_page_id"]},
        title=[{"type":"text","text":{"content":"📈 포트폴리오 현황"}}], properties=notion_schema())
    print("database_id:", db["id"], "\n→ config.yaml 에 넣어주세요.")

def sync_notion(config, d):
    from notion_client import Client
    n = config["notion"]; c = Client(auth=n["token"]); db = n["database_id"]
    for p in c.databases.query(database_id=db).get("results", []):
        c.pages.update(page_id=p["id"], archived=True)
    today = dt.date.today().isoformat()
    for b, brs in d["buckets"].items():
        for r in brs:
            c.pages.create(parent={"database_id":db}, properties={
                "종목":{"title":[{"text":{"content":r["name"]}}]},
                "버킷":{"select":{"name":b}},
                "티커":{"rich_text":[{"text":{"content":r["ticker"]}}]},
                "수량":{"number":r["shares"]},
                "평가금액(원)":{"number":round(r["value_krw"])},
                "손익률":{"number":round(r["pnl_pct"],4)},
                "비중":{"number":round(r["weight"],4)},
                "업데이트":{"date":{"start":today}}})
    print("Notion 동기화 완료")


# ── 엔트리 ──────────────────────────────────────────────
def main():
    config = load_config()
    if "--setup-notion" in sys.argv:
        setup_notion(config); return
    holdings = load_holdings()
    print(f"보유 {len(holdings)}행 시세 조회 중...")
    usdkrw = get_usdkrw()
    quotes = {}
    for h in holdings:
        if h["ticker"] not in quotes:
            quotes[h["ticker"]] = fetch_quote(h)
            q = quotes[h["ticker"]]
            print(f"  {h['ticker']:<8} {str(q['name'])[:18]:<18} {q['price']:,.2f} {q['currency']}")
    d = compute(holdings, quotes, usdkrw, config)
    html = render_html(d)
    # finance.yaml 있으면 재무건강 섹션을 같이 붙임 (통합본 A)
    fin_path = BASE / "finance.yaml"
    if fin_path.exists():
        try:
            import finance_health as fh
            fc = yaml.safe_load(open(fin_path, encoding="utf-8"))
            fd = fh.compute(fc)
            fin_body = "<h1 style='margin-top:34px'>🩺 재무건강</h1>" + fh.section_html(fd, standalone=False)
            html = html.replace("</style>", fh.CSS + "</style>", 1)
            html = html.replace("<div class=\"fx\">", fin_body + "<div class=\"fx\">", 1)
        except Exception as e:
            print(f"(재무건강 섹션 생략: {e})")
    OUTPUT_HTML.write_text(html, encoding="utf-8")
    print(f"\n대시보드: {OUTPUT_HTML}")
    print(f"총 평가 {won(d['total_value'])} / 손익 {won(d['total_pnl'])} ({pct(d['total_pnl_pct'])})")
    for b, s in d["bucket_summ"].items():
        print(f"  [{b}] {won(s['value'])} ({pct(s['pnl_pct'])})")
    if config.get("notion", {}).get("enabled"):
        sync_notion(config, d)

if __name__ == "__main__":
    main()
